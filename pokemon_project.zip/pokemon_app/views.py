import random
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import logout
from .models import Pokemon, UserPokemon, UserProfile, Message
from django.db.models import Count
from .forms import TeamSelectionForm


def index(request):
    """Homepage view"""
    # Get 5 random Pokémon to display
    random_pokemon = Pokemon.objects.order_by('?')[:5]

    user_pokemon_count = 0
    if request.user.is_authenticated:
        user_pokemon_count = UserPokemon.objects.filter(user=request.user).count()
    
    # Get profiles for leaderboard (only those with selected pokemon)
    profiles = UserProfile.objects.annotate(
        pokemon_count=Count('selected_pokemon')
    ).filter(pokemon_count__gt=0).order_by('-pokemon_count')[:5]

    return render(request, 'pokemon_app/index.html', {
        'random_pokemon': random_pokemon,
        'user_pokemon_count': user_pokemon_count,
        'profiles': profiles,  # Add profiles to context
    })

def custom_logout(request):
    """Custom logout view that accepts both GET and POST methods"""
    logout(request)
    messages.success(request, "You have been successfully logged out.")
    return redirect('index')

def pokemon_list(request):
    """View all available Pokémon"""
    pokemon = Pokemon.objects.all().order_by('pokedex_id')
    return render(request, 'pokemon_app/pokemon_list.html', {'pokemon': pokemon})


def pokemon_detail(request, pokemon_id):
    """View details of a specific Pokémon"""
    pokemon = get_object_or_404(Pokemon, pokedex_id=pokemon_id)

    # Check if user owns this Pokémon
    user_pokemon = None
    if request.user.is_authenticated:
        user_pokemon = UserPokemon.objects.filter(user=request.user, pokemon=pokemon)

    return render(request, 'pokemon_app/pokemon_detail.html', {
        'pokemon': pokemon,
        'user_pokemon': user_pokemon,
    })


@login_required
def generate_pokemon(request):
    """Generate a random Pokémon for the user"""
    if request.method == 'POST':
        # Select a random Pokémon
        random_id = random.randint(1, 151)
        pokemon = get_object_or_404(Pokemon, pokedex_id=random_id)

        # Generate random IVs (0-31, like in the actual games)
        iv_hp = random.randint(0, 31)
        iv_attack = random.randint(0, 31)
        iv_defense = random.randint(0, 31)
        iv_special_attack = random.randint(0, 31)
        iv_special_defense = random.randint(0, 31)
        iv_speed = random.randint(0, 31)

        # Create a new UserPokemon
        user_pokemon = UserPokemon(
            user=request.user,
            pokemon=pokemon,
            iv_hp=iv_hp,
            iv_attack=iv_attack,
            iv_defense=iv_defense,
            iv_special_attack=iv_special_attack,
            iv_special_defense=iv_special_defense,
            iv_speed=iv_speed,
        )
        user_pokemon.save()

        messages.success(request, f'You caught a {pokemon.name}!')
        return redirect('my_pokemon')

    return redirect('index')


@login_required
def my_pokemon(request):
    """View all Pokémon owned by the user"""
    user_pokemon = UserPokemon.objects.filter(user=request.user).order_by('-capture_date')
    return render(request, 'pokemon_app/my_pokemon.html', {'user_pokemon': user_pokemon})


@login_required
def nickname_pokemon(request, user_pokemon_id):
    """Give a nickname to a Pokémon"""
    if request.method == 'POST':
        user_pokemon = get_object_or_404(UserPokemon, id=user_pokemon_id, user=request.user)
        nickname = request.POST.get('nickname', '').strip()

        if nickname:
            user_pokemon.nickname = nickname
            user_pokemon.save()
            messages.success(request, f'Your {user_pokemon.pokemon.name} is now known as {nickname}!')
        else:
            messages.error(request, 'Please provide a valid nickname.')

    return redirect('my_pokemon')


@login_required
def release_pokemon(request, user_pokemon_id):
    """Release a Pokémon back into the wild"""
    if request.method == 'POST':
        user_pokemon = get_object_or_404(UserPokemon, id=user_pokemon_id, user=request.user)
        pokemon_name = user_pokemon.nickname or user_pokemon.pokemon.name
        user_pokemon.delete()
        messages.success(request, f'You released {pokemon_name} back into the wild.')

    return redirect('my_pokemon')

@login_required
def select_pokemon(request):
    """View for selecting pokemon for the leaderboard team"""
    # Get or create user profile
    profile, created = UserProfile.objects.get_or_create(user=request.user)
    
    # Get all user's pokemon
    user_pokemon = UserPokemon.objects.filter(user=request.user)
    
    # Get currently selected pokemon IDs
    selected_ids = [p.id for p in profile.selected_pokemon.all()]
    
    if request.method == 'POST':
        # Get selected pokemon IDs from form
        selected_ids = request.POST.getlist('selected_pokemon')
        
        # Validate maximum of 6 selections
        if len(selected_ids) > 6:
            messages.error(request, "You can only select up to 6 Pokémon for your team.")
        else:
            # Clear current selections
            profile.selected_pokemon.clear()
            
            # Add new selections
            for pokemon_id in selected_ids:
                pokemon = get_object_or_404(UserPokemon, id=pokemon_id, user=request.user)
                profile.selected_pokemon.add(pokemon)
            
            messages.success(request, "Your team has been updated!")
            return redirect('index')
    
    return render(request, 'pokemon_app/select_pokemon.html', {
        'user_pokemon': user_pokemon,
        'selected_ids': [int(id) for id in selected_ids],
    })

def leaderboard(request):
    """Full leaderboard view"""
    profiles = UserProfile.objects.annotate(
        pokemon_count=Count('selected_pokemon')
    ).filter(pokemon_count__gt=0).order_by('-pokemon_count')
    
    # Check if user has team
    has_team = False
    if request.user.is_authenticated:
        try:
            profile = UserProfile.objects.get(user=request.user)
            has_team = profile.selected_pokemon.exists()
        except UserProfile.DoesNotExist:
            pass
    
    return render(request, 'pokemon_app/leaderboard.html', {
        'profiles': profiles,
        'has_team': has_team,
    })

@login_required
def message_board(request):
    """View for the message board page"""
    # Get all messages ordered by timestamp (newest first, handled by model's Meta ordering)
    all_messages = Message.objects.all()
    
    # Handle new message submission
    if request.method == 'POST':
        content = request.POST.get('message_content', '').strip()
        if content:
            # Create a new message
            Message.objects.create(user=request.user, content=content)
            messages.success(request, "Your message has been posted!")
            return redirect('message_board')  # Redirect to refresh the page
        else:
            messages.error(request, "Message cannot be empty!")
    
    return render(request, 'pokemon_app/message_board.html', {
        'all_messages': all_messages,
    })

# Create your views here.

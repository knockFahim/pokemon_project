from django.apps import AppConfig


class PokemonAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pokemon_app'

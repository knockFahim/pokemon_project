from django import forms
from .models import UserProfile, UserPokemon

class TeamSelectionForm(forms.Form):
    selected_pokemon = forms.ModelMultipleChoiceField(
        queryset=UserPokemon.objects.none(),  # Will be set in __init__
        widget=forms.CheckboxSelectMultiple,
        required=False
    )

    def __init__(self, user, *args, **kwargs):
        super(TeamSelectionForm, self).__init__(*args, **kwargs)
        # Only show pokemon owned by this user
        self.fields['selected_pokemon'].queryset = UserPokemon.objects.filter(user=user)

    def clean_selected_pokemon(self):
        selected = self.cleaned_data['selected_pokemon']
        if len(selected) > 6:
            raise forms.ValidationError("You can only select up to 6 Pokémon for your team.")
        return selected